﻿namespace Notes.Context;


public enum DbType
{
    PgSql = 0
}